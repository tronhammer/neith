print "Commands are being read in..."
__all__ = ["basic", "connect", "info"]