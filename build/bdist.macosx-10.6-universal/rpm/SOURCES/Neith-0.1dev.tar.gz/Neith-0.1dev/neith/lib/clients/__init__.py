print "Clients are being read in..."
__all__ = ["guest", "application", "service"]
